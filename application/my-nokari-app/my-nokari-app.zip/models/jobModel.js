exports.jobs = [
  {
    id: 1,
    title: "Frontend Developer",
    company: "Gruve AI",
    location: "Remote",
    salary: "₹12-18 LPA",
  },
  {
    id: 2,
    title: "Backend Engineer",
    company: "TechNova",
    location: "Bangalore",
    salary: "₹15-22 LPA",
  },
  {
    id: 3,
    title: "Data Scientist",
    company: "DataWiz",
    location: "Pune",
    salary: "₹18-25 LPA",
  },
];
